# 🌾 FarmDosth – Smart AI Farming Companion

A mobile-first, multilingual farming assistant prototype for Indian farmers.

## Features
- Ask by typing or voice; spoken answers (uses the phone's built-in voices)
- 22 official Indian languages plus "Other language"
- Camera and gallery photo capture; photos are saved on the phone when offline
- Basic offline advice (yellow leaves, brown spots, pests)
- Crop calendar, soil-report explainer, saved advice, share to WhatsApp, large-text mode

## Run it
It is a single static file. Open `index.html` in a browser, or host it free with GitHub Pages
(Settings → Pages → Deploy from branch → `main` / root).

## Important limits
- **AI features** (photo analysis, any-language translation, soil-report explainer) were built for the
  claude.ai artifact runtime. On GitHub Pages or a local file they do **not** run; the app falls back
  to the built-in offline advice.
- Weather and market prices are **sample data**.
- Advice is a first guess, never a confirmed diagnosis. Always confirm with a local agriculture officer or KVK before spraying.

## Roadmap
- FastAPI backend + PostgreSQL
- RAG over trusted sources (ICAR, state agricultural universities)
- Crop-disease image model
- Live weather and mandi-price APIs
- PWA service worker for true offline install

## Security
Never put API keys in this front-end. Keep them in backend environment variables.
